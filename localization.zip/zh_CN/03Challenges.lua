return {
    misc = {
        challenge_names = {
            c_joy_mystic_wok = "神秘锅",
            c_joy_mistake = "失误",
            c_joy_monster_reborn = "死者苏生",
            c_joy_domain = "真帝王领域",
        },
        v_text = {
            ch_c_joy_gy_start = {
                "初始时{C:attention}墓地{}中有一些卡牌",
            },
            ch_c_joy_extra_deck_slots = {
                "初始拥有{C:attention}#1#{}个{C:joy_spell}额外卡组{}栏位",
            },
            ch_c_joy_no_extra_deck_jokers = {
                "商店中不会出现{C:joy_spell}额外卡组{} {C:attention}小丑牌{}",
            },
        },
    }
}