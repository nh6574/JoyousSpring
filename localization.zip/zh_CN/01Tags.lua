return {
    descriptions = {
        Tag = {
            tag_joy_booster = {
                name = "补充包标签",
                text = {
                    "在下一个商店添加一个{C:booster}补充包",
                    "",
                },
            },
            tag_joy_monster = {
                name = "怪兽标签",
                text = {
                    "添加",
                    "{V:1}#1#{}",
                    "到商店",
                },
            },
        },
    },
    misc = {
        dictionary = {
            k_joy_monster_tag_default = "一张怪兽小丑牌",
        }
    }
}