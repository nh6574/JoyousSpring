return {
    misc = {
        dictionary = {
            k_joy_disable_tooltips = "禁用术语表提示",
            k_joy_disable_booster_tag = "禁用补充包标签自然出现",
            k_joy_disable_main_menu = "禁用主菜单修改",
            k_joy_only_ygo_cards = "仅出现怪兽牌",
            k_joy_extra_ygo_booster = "每个商店额外增加一个怪兽牌补充包",
            k_joy_instant_poker_hand = "禁用牌型升级动画（本模组）",
            k_joy_disable_glow = "禁用可发动卡牌的发光效果",
        }
    }
}