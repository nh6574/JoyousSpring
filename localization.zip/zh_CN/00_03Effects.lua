return {
    misc = {
        dictionary = {
            k_joy_activated_ex = "已发动！",
            k_joy_token = "衍生物",
            k_joy_splash = "飞溅！",
            k_joy_defeated = "已击败！",
            k_joy_banished = "已除外！",
            k_joy_flip_ex = "反转！",
            k_joy_set = "已放置！",
            k_joy_revive = "复活！",
            k_joy_mill = "送入墓地！",
            k_joy_add = "已添加！",
            k_joy_return = "已返回！",
            k_joy_excavate = "发掘！",
            k_joy_hit = "命中！",
            k_joy_transferred = "已转移！",
            k_joy_doubled = "已翻倍！",
            k_joy_increased = "已提升！",
            k_joy_attach = "已附着！",
        }
    }
}