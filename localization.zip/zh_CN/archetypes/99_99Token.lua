-- 文件 8：99_99Token.lua（已汉化）
return {
    descriptions = {
        Joker = {
            j_joy_token = {
                name = "{C:joy_token}衍生物",
                text = {
                    {
                        "此卡可视为任意{C:joy_token}衍生物{C:attention}"
                    },
                },
            },
        }
    },
    misc = {
        dictionary = {
            k_joy_archetype_token = "衍生物",
        }
    },
}