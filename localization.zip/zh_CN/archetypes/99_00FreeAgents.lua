-- 文件 9：99_00FreeAgents.lua（已汉化）
return {
    misc = {
        dictionary = {
            k_joy_archetype_misc = "自由势力",
        }
    },
}